﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ITI.Map2D
{
    public class Box
    {
        readonly Map _map;
        readonly int _line;
        readonly int _column;

        public Box( Map map, int line, int column )
        {
            _map = map;
            _line = line;
            _column = column;
        }

        public Rectangle Area
        {
            get
            {
                int sz = _map.BoxWidth;
                return new Rectangle( _column * sz, _line * sz, sz, sz );
            }
        }

        static Pen _p1 = new Pen( Color.Red, 1.0f );
        static Pen _p2 = new Pen( Color.Blue, 1.0f );

        public virtual void Draw( Graphics g, Rectangle rectSource, float scaleFactor )
        {
            Rectangle r = new Rectangle( 0, 0, _map.BoxWidth - 1, _map.BoxWidth - 1 );
            Pen p = _line % 2 == 0 ? _p1 : _p2;
            for( int i = 0; i < 5; ++i )
            {
                if( _column % 2 == 0 ) g.DrawEllipse( p, r );
                else g.DrawRectangle( p, r );
                r.Inflate( -_map.BoxWidth / 12, -_map.BoxWidth / 12 );
            }
        }
    }
}
